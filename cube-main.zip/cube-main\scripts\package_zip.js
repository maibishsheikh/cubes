// scripts/package_zip.js
// Packages cube-main.zip excluding node_modules, dist, reference_repo, and zips
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const rootDir = path.resolve('.');
const targetZip = path.join(rootDir, 'cube-main.zip');
const tempDir = path.join(rootDir, 'temp_package', 'cube-main');

console.log("📦 Packaging clean repository into cube-main.zip...");

if (fs.existsSync(path.join(rootDir, 'temp_package'))) {
  fs.rmSync(path.join(rootDir, 'temp_package'), { recursive: true, force: true });
}
if (fs.existsSync(targetZip)) {
  fs.unlinkSync(targetZip);
}

fs.mkdirSync(tempDir, { recursive: true });

const items = [
  'public',
  'scripts',
  'src',
  'index.html',
  'package.json',
  'package-lock.json',
  'postcss.config.js',
  'tailwind.config.js',
  'vercel.json',
  'vite.config.js',
  '.oxlintrc.json',
  '.gitignore',
  '.env.local.example',
  'README.md'
];

for (const item of items) {
  const srcPath = path.join(rootDir, item);
  const destPath = path.join(tempDir, item);
  if (fs.existsSync(srcPath)) {
    fs.cpSync(srcPath, destPath, { recursive: true });
  }
}

// Compress using PowerShell Compress-Archive
const parentTemp = path.join(rootDir, 'temp_package', 'cube-main');
const psCmd = `powershell -Command "Compress-Archive -Path '${parentTemp}' -DestinationPath '${targetZip}' -CompressionLevel Optimal"`;
execSync(psCmd, { stdio: 'inherit' });

fs.rmSync(path.join(rootDir, 'temp_package'), { recursive: true, force: true });

const stats = fs.statSync(targetZip);
console.log(`✅ Successfully created cube-main.zip (${(stats.size / 1024 / 1024).toFixed(2)} MB)!`);
